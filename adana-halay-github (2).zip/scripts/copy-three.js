// three.min.js'i www/ içine kopyalar; APK internetsiz de çalışsın.
const fs = require('fs'), path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three', 'build', 'three.min.js');
const dst = path.join(__dirname, '..', 'www', 'three.min.js');
if (!fs.existsSync(src)) { console.error('three.min.js bulunamadı, npm install çalıştır.'); process.exit(1); }
fs.copyFileSync(src, dst);
console.log('three.min.js kopyalandı:', dst);
