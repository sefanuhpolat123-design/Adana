'use strict';
/* Anafor & Hülya Düğünü — Three.js halay simülasyonu */
const $ = id => document.getElementById(id);
const rnd = (a, b) => a + Math.random() * (b - a);
const pick = a => a[Math.floor(Math.random() * a.length)];
const SPONSOR = 'medya.com38';
const NAMES = ['Mehmet','Ayşe','Osman','Zeynep','Hasan','Elif','Kemal','Fatma','Burak','Seda','Cemal','Derya','Yusuf','Büşra','Tuncay','Gül'];

/* ---------- Sahne ---------- */
const scene = new THREE.Scene();
scene.background = new THREE.Color(0x070711);
scene.fog = new THREE.FogExp2(0x070711, 0.018);
const cam = new THREE.PerspectiveCamera(55, 1, 0.1, 200);
const camBase = new THREE.Vector3(0, 11, 24);
const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
$('stage').appendChild(renderer.domElement);
function resize() {
  renderer.setSize(innerWidth, innerHeight);
  cam.aspect = innerWidth / innerHeight;
  cam.updateProjectionMatrix();
  camBase.z = cam.aspect < 1 ? 34 : 24;
}
addEventListener('resize', resize); resize();

scene.add(new THREE.HemisphereLight(0x8899ff, 0x221122, 0.7));
const sun = new THREE.DirectionalLight(0xffeedd, 0.6); sun.position.set(8, 20, 12); scene.add(sun);
const sirenRed = new THREE.PointLight(0xff0000, 0, 60); sirenRed.position.set(-12, 6, 8);
const sirenBlue = new THREE.PointLight(0x0044ff, 0, 60); sirenBlue.position.set(12, 6, 8);
scene.add(sirenRed, sirenBlue);

const ground = new THREE.Mesh(new THREE.PlaneGeometry(120, 120), new THREE.MeshStandardMaterial({ color: 0x1a1a24, roughness: 0.9 }));
ground.rotation.x = -Math.PI / 2; scene.add(ground);

// Apartmanlar (ışıklı pencere dokusu)
function windowTexture() {
  const c = document.createElement('canvas'); c.width = 64; c.height = 128;
  const x = c.getContext('2d'); x.fillStyle = '#15151f'; x.fillRect(0, 0, 64, 128);
  for (let i = 0; i < 4; i++) for (let j = 0; j < 8; j++) {
    x.fillStyle = Math.random() < 0.5 ? '#ffd86b' : '#222233'; x.fillRect(6 + i * 15, 6 + j * 15, 9, 10);
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; return t;
}
const winTex = windowTexture();
for (const side of [-1, 1]) for (let z = -18; z <= 16; z += 9) {
  const h = rnd(14, 26), tex = winTex.clone(); tex.needsUpdate = true; tex.repeat.set(2, Math.round(h / 4));
  const b = new THREE.Mesh(new THREE.BoxGeometry(8, h, 8), new THREE.MeshStandardMaterial({ map: tex, emissive: 0xffffff, emissiveMap: tex, emissiveIntensity: 0.5 }));
  b.position.set(side * 24, h / 2, z); scene.add(b);
}

// Ampuller
const bulbs = [];
const bulbColors = [0xff2222, 0x22ff22, 0x22ffff, 0xff22ff, 0xffff22];
for (let i = 0; i < 28; i++) {
  const t = i / 27, m = new THREE.Mesh(new THREE.SphereGeometry(0.2, 8, 8), new THREE.MeshBasicMaterial({ color: bulbColors[i % 5] }));
  m.position.set(-22 + t * 44, 10 - Math.abs(Math.sin(t * Math.PI * 4)) * 1.2, -4);
  scene.add(m); bulbs.push(m);
}

/* ---------- LED ekran ---------- */
const ledCanvas = document.createElement('canvas'); ledCanvas.width = 512; ledCanvas.height = 256;
const ledCtx = ledCanvas.getContext('2d'), ledTex = new THREE.CanvasTexture(ledCanvas);
let ledMsg = 'Hediye bekleniyor...', ledX = 0, ledLast = 0;
function drawLED(now) {
  if (now - ledLast < 60) return; ledLast = now;
  const c = ledCtx; c.fillStyle = '#05051a'; c.fillRect(0, 0, 512, 256);
  c.strokeStyle = '#fc0'; c.lineWidth = 6; c.strokeRect(6, 6, 500, 244);
  c.textAlign = 'center'; c.fillStyle = '#ff4fa3'; c.font = 'bold 54px sans-serif'; c.fillText('ANAFOR & HÜLYA', 256, 90);
  c.fillStyle = '#0ff'; c.font = 'bold 28px sans-serif'; c.fillText('01 ADANA HÜRRİYET', 256, 135);
  c.textAlign = 'left'; c.fillStyle = '#f90'; c.font = 'bold 30px sans-serif';
  const s = `${SPONSOR}  •  ${ledMsg}  •  `, w = Math.max(c.measureText(s).width, 200);
  ledX = (ledX - 4) % w;
  for (let x = ledX; x < 512; x += w) c.fillText(s, x, 215);
  ledTex.needsUpdate = true;
}
const dark = new THREE.MeshBasicMaterial({ color: 0x111111 });
const led = new THREE.Mesh(new THREE.BoxGeometry(12, 6, 0.3), [dark, dark, dark, dark, new THREE.MeshBasicMaterial({ map: ledTex }), dark]);
led.position.set(0, 5.5, -14); scene.add(led);

/* ---------- Karakter ---------- */
function label(text, color = '#fff') {
  const c = document.createElement('canvas'); c.width = 256; c.height = 64; const x = c.getContext('2d');
  x.fillStyle = '#000a'; x.fillRect(0, 8, 256, 48); x.fillStyle = color; x.font = 'bold 30px sans-serif'; x.textAlign = 'center'; x.fillText(text, 128, 44);
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: new THREE.CanvasTexture(c), transparent: true, depthTest: false }));
  s.scale.set(3, 0.75, 1); s.position.y = 3.1; return s;
}
function makePerson(color, name, dress = false) {
  const g = new THREE.Group(), mat = c => new THREE.MeshStandardMaterial({ color: c, roughness: 0.7 }), skin = 0xf1c27d;
  const body = new THREE.Mesh(dress ? new THREE.ConeGeometry(0.6, 1.5, 12) : new THREE.BoxGeometry(0.7, 1.1, 0.4), mat(color)); body.position.y = dress ? 1.2 : 1.35;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.28, 12, 12), mat(skin)); head.position.y = 2.05;
  const hair = new THREE.Mesh(new THREE.SphereGeometry(0.3, 12, 8, 0, Math.PI * 2, 0, Math.PI / 2), mat(dress ? 0x331100 : 0x111111)); hair.position.y = 2.1;
  const limb = (w, h, c, x, y) => { const p = new THREE.Group(); p.position.set(x, y, 0); const m = new THREE.Mesh(new THREE.BoxGeometry(w, h, w), mat(c)); m.position.y = -h / 2; p.add(m); return p; };
  const lL = limb(0.24, 0.8, 0x222244, -0.18, 0.8), lR = limb(0.24, 0.8, 0x222244, 0.18, 0.8);
  const aL = limb(0.17, 0.75, color, -0.46, 1.85), aR = limb(0.17, 0.75, color, 0.46, 1.85);
  const crown = new THREE.Mesh(new THREE.ConeGeometry(0.22, 0.4, 5), new THREE.MeshStandardMaterial({ color: 0xffcc00, emissive: 0xaa8800 })); crown.position.y = 2.6; crown.visible = false;
  g.add(body, head, hair, lL, lR, aL, aR, crown);
  if (name) g.add(label(name, dress ? '#ff7ac8' : '#fff'));
  return { g, lL, lR, aL, aR, crown };
}

// VIP masa: Anafor & Hülya
const table = new THREE.Mesh(new THREE.BoxGeometry(5, 0.2, 2), new THREE.MeshStandardMaterial({ color: 0x8b4513 }));
table.position.set(0, 1.3, -10);
const tableBase = new THREE.Mesh(new THREE.BoxGeometry(4.6, 1.2, 1.6), new THREE.MeshStandardMaterial({ color: 0x5a2d0c })); tableBase.position.set(0, 0.6, -10);
scene.add(table, tableBase);
[['Anafor', 0x222222, -1.2, false], ['Hülya', 0xff1493, 1.2, true]].forEach(([n, c, x, d]) => {
  const p = makePerson(c, n, d); p.g.position.set(x, 0.3, -11.2); scene.add(p.g);
  p.aL.rotation.z = 0.2; p.aR.rotation.z = -0.2;
});

/* ---------- Parçacıklar ---------- */
const MAXP = 1800, pPos = new Float32Array(MAXP * 3), pCol = new Float32Array(MAXP * 3);
const pVel = new Float32Array(MAXP * 3), pLife = new Float32Array(MAXP), pGrav = new Float32Array(MAXP);
pPos.fill(-999);
const pGeo = new THREE.BufferGeometry();
pGeo.setAttribute('position', new THREE.BufferAttribute(pPos, 3)); pGeo.setAttribute('color', new THREE.BufferAttribute(pCol, 3));
const points = new THREE.Points(pGeo, new THREE.PointsMaterial({ size: 0.45, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
points.frustumCulled = false; scene.add(points);
let pi = 0;
function emit(x, y, z, vx, vy, vz, color, life, grav = -6) {
  const i = pi; pi = (pi + 1) % MAXP; const c = new THREE.Color(color);
  pPos.set([x, y, z], i * 3); pVel.set([vx, vy, vz], i * 3); pCol.set([c.r, c.g, c.b], i * 3); pLife[i] = life; pGrav[i] = grav;
}
function stepParticles(dt) {
  for (let i = 0; i < MAXP; i++) {
    if (pLife[i] <= 0) continue;
    pLife[i] -= dt; const k = i * 3;
    if (pLife[i] <= 0) { pPos[k + 1] = -999; continue; }
    pVel[k + 1] += pGrav[i] * dt;
    pPos[k] += pVel[k] * dt; pPos[k + 1] += pVel[k + 1] * dt; pPos[k + 2] += pVel[k + 2] * dt;
  }
  pGeo.attributes.position.needsUpdate = true; pGeo.attributes.color.needsUpdate = true;
}

/* ---------- Halay ---------- */
const CENTER = new THREE.Vector3(0, 0, 3), MAX_DANCERS = 40;
const dancers = []; let ringAngle = 0, raidT = -1, leader = null;
function addDancer(name) {
  if (dancers.some(d => d.name === name) || dancers.length >= MAX_DANCERS) return false;
  const p = makePerson(new THREE.Color().setHSL(Math.random(), 0.7, 0.5).getHex(), name);
  const edge = Math.random() < 0.5 ? -1 : 1;
  const d = { ...p, name, pos: new THREE.Vector3(edge * 32, 0, rnd(6, 14)), ph: Math.random() * 6, flee: new THREE.Vector3() };
  p.g.position.copy(d.pos); scene.add(p.g); dancers.push(d);
  if (!leader) setLeader(d);
  return true;
}
function setLeader(d) { if (leader) leader.crown.visible = false; leader = d; d.crown.visible = true; }

/* ---------- Efektler ---------- */
const fx = []; // { update(dt) -> false dönerse biter }
function firework() {
  const x = rnd(-9, 9), y = rnd(11, 17), z = rnd(-8, 0), col = pick([0xff3355, 0x33ff88, 0x44aaff, 0xffdd33, 0xff66ff]);
  for (let i = 0; i < 90; i++) {
    const th = Math.random() * Math.PI * 2, ph = Math.acos(rnd(-1, 1)), s = rnd(4, 8);
    emit(x, y, z, Math.sin(ph) * Math.cos(th) * s, Math.sin(ph) * Math.sin(th) * s, Math.cos(ph) * s, col, rnd(1, 1.8), -5);
  }
  sfx.boom();
}
function petals() { for (let i = 0; i < 140; i++) emit(rnd(-8, 8), rnd(10, 14), rnd(-4, 10), rnd(-.5, .5), rnd(-2, -.5), rnd(-.5, .5), pick([0xff6699, 0xff3366, 0xffaacc]), rnd(3, 5), -0.3); }
function motorcycle() {
  const g = new THREE.Group(), blk = new THREE.MeshStandardMaterial({ color: 0x222222 });
  const wheel = () => { const w = new THREE.Mesh(new THREE.TorusGeometry(0.4, 0.12, 8, 16), blk); w.rotation.y = Math.PI / 2; return w; };
  const w1 = wheel(), w2 = wheel(); w1.position.set(0, 0.45, 0.8); w2.position.set(0, 0.45, -0.8);
  const body = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.5, 1.5), new THREE.MeshStandardMaterial({ color: 0xcc1111 })); body.position.y = 0.9;
  const rider = makePerson(0x2255cc, ''); rider.g.scale.setScalar(0.7); rider.g.position.y = 0.4;
  g.add(w1, w2, body, rider.g); scene.add(g);
  let t = 0; sfx.engine();
  fx.push({ update(dt) {
    t += dt; const a = t * 1.6;
    g.position.set(Math.cos(a) * 9, 0, 3 + Math.sin(a) * 9); g.rotation.y = Math.atan2(-Math.sin(a), Math.cos(a));
    g.updateMatrixWorld(true);
    w1.rotation.x = w2.rotation.x = t * 30;
    const rear = new THREE.Vector3(0, 0.3, -0.8).applyMatrix4(g.matrixWorld);
    for (let i = 0; i < 6; i++) emit(rear.x, rear.y, rear.z, rnd(-1, 1), rnd(.5, 2), rnd(-1, 1), 0xaaaaaa, rnd(1, 2.2), 0.5);
    if (t > 6) { scene.remove(g); return false; } return true;
  } });
}
function raid() {
  if (raidT >= 0) return; raidT = 0;
  dancers.forEach(d => d.flee.copy(d.pos).sub(CENTER).setY(0).normalize().multiplyScalar(40).add(CENTER));
  const mk = () => {
    const c = new THREE.Group(), b = new THREE.Mesh(new THREE.BoxGeometry(2, 1, 4), new THREE.MeshStandardMaterial({ color: 0xeeeeee })); b.position.y = 0.8;
    const l1 = new THREE.Mesh(new THREE.BoxGeometry(.5, .25, .6), new THREE.MeshBasicMaterial({ color: 0xff0000 }));
    const l2 = new THREE.Mesh(new THREE.BoxGeometry(.5, .25, .6), new THREE.MeshBasicMaterial({ color: 0x0044ff }));
    l1.position.set(-.5, 1.45, 0); l2.position.set(.5, 1.45, 0); c.add(b, l1, l2); c.userData = { l1, l2 }; scene.add(c); return c;
  };
  const cars = [mk(), mk()]; cars[0].rotation.y = Math.PI / 2; cars[1].rotation.y = -Math.PI / 2; sfx.siren();
  let t = 0;
  fx.push({ update(dt) {
    t += dt; const e = Math.min(t / 1.5, 1), out = t > 4.5 ? (t - 4.5) * 12 : 0, flash = Math.floor(t * 6) % 2;
    cars[0].position.set(-32 + 22 * e - out, 0, 9); cars[1].position.set(32 - 22 * e + out, 0, 11);
    sirenRed.intensity = flash ? 4 : 0; sirenBlue.intensity = flash ? 0 : 4;
    cars.forEach(c => { c.userData.l1.visible = !!flash; c.userData.l2.visible = !flash; });
    if (t > 6) { cars.forEach(c => scene.remove(c)); sirenRed.intensity = sirenBlue.intensity = 0; return false; } return true;
  } });
}

/* ---------- Ses (WebAudio ile üretilen davul-zurna) ---------- */
const sfx = (() => {
  let ac, master, timer, step = 0, on = false, note = 0;
  const init = () => { if (ac) return; ac = new (window.AudioContext || window.webkitAudioContext)(); master = ac.createGain(); master.gain.value = 0.5; master.connect(ac.destination); };
  const noise = (t, dur, f, vol) => {
    const n = Math.floor(ac.sampleRate * dur), b = ac.createBuffer(1, n, ac.sampleRate), d = b.getChannelData(0);
    for (let i = 0; i < n; i++) d[i] = Math.random() * 2 - 1;
    const s = ac.createBufferSource(), fl = ac.createBiquadFilter(), g = ac.createGain();
    s.buffer = b; fl.type = 'bandpass'; fl.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    s.connect(fl); fl.connect(g); g.connect(master); s.start(t);
  };
  const kick = t => {
    const o = ac.createOscillator(), g = ac.createGain();
    o.frequency.setValueAtTime(140, t); o.frequency.exponentialRampToValueAtTime(45, t + 0.15);
    g.gain.setValueAtTime(1, t); g.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
    o.connect(g); g.connect(master); o.start(t); o.stop(t + 0.3);
  };
  const scale = [0, 1, 4, 5, 7, 8, 11, 12, 13]; // Hicaz
  const zurna = (t, dur) => {
    const f = 220 * Math.pow(2, scale[note] / 12), o = ac.createOscillator(), v = ac.createOscillator(), vg = ac.createGain(), fl = ac.createBiquadFilter(), g = ac.createGain();
    o.type = 'sawtooth'; o.frequency.value = f; v.frequency.value = 6; vg.gain.value = 5; v.connect(vg); vg.connect(o.frequency);
    fl.type = 'bandpass'; fl.frequency.value = 1400; fl.Q.value = 2;
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.18, t + 0.03); g.gain.exponentialRampToValueAtTime(0.001, t + dur);
    o.connect(fl); fl.connect(g); g.connect(master); o.start(t); v.start(t); o.stop(t + dur); v.stop(t + dur);
  };
  const tick = () => {
    const t = ac.currentTime + 0.05, s = step % 8;
    if (s === 0 || s === 3 || s === 4) kick(t);
    if (s === 2 || s === 6 || s === 7) noise(t, 0.08, 4000, 0.4);
    if (s % 2 === 0) { note = Math.max(0, Math.min(scale.length - 1, note + pick([-2, -1, 0, 1, 2]))); zurna(t, 0.4); }
    step++;
  };
  const tone = (type, dur, setup) => {
    if (!ac) return; const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
    o.type = type; setup(o, g, t); o.connect(g); g.connect(master); o.start(t); o.stop(t + dur);
  };
  return {
    toggle() { init(); ac.resume(); on = !on; if (on) timer = setInterval(tick, 140); else clearInterval(timer); return on; },
    boom() { if (ac) noise(ac.currentTime, 0.6, 300, 0.7); },
    engine() { tone('sawtooth', 6, (o, g, t) => { o.frequency.setValueAtTime(70, t); o.frequency.linearRampToValueAtTime(220, t + 5); g.gain.setValueAtTime(0.25, t); g.gain.linearRampToValueAtTime(0, t + 6); }); },
    siren() { tone('square', 6, (o, g, t) => { for (let i = 0; i < 12; i++) o.frequency.setValueAtTime(i % 2 ? 700 : 950, t + i * 0.5); g.gain.setValueAtTime(0.15, t); g.gain.setValueAtTime(0.15, t + 5.5); g.gain.linearRampToValueAtTime(0, t + 6); }); },
  };
})();

/* ---------- Anlatıcı (TTS) ---------- */
let ttsPending = 0;
function speak(text) {
  if (!('speechSynthesis' in window) || ttsPending > 2) return;
  const u = new SpeechSynthesisUtterance(text); u.lang = 'tr-TR'; u.rate = 1.1; ttsPending++;
  u.onend = u.onerror = () => { ttsPending = Math.max(0, ttsPending - 1); }; speechSynthesis.speak(u);
}

/* ---------- Hediyeler ve sohbet ---------- */
const GIFTS = [
  { name: 'Gül', coin: 1, emoji: '🌹', run: () => { petals(); const d = pick(dancers); if (d) { setLeader(d); setTicker(`${d.name} halay başı oldu!`); } } },
  { name: 'Motor Lastik Yakma', coin: 20, emoji: '🏍️', run: motorcycle },
  { name: 'Havai Fişek', coin: 50, emoji: '🎆', run: () => { for (let i = 0; i < 6; i++) setTimeout(firework, i * 350); } },
  { name: 'Düğün Baskını', coin: 100, emoji: '🚨', run: raid },
];
function setTicker(t) { ledMsg = t; $('ticker').textContent = '🔴 ' + t + ' | ' + SPONSOR; }
function logChat(t) { const d = document.createElement('div'); d.textContent = t; const l = $('log'); l.appendChild(d); while (l.children.length > 30) l.firstChild.remove(); l.scrollTop = l.scrollHeight; }
function userName() { return $('name').value.trim() || 'Misafir'; }
function sendGift(g, from = userName()) {
  setTicker(`${from} ${g.coin} coin değerinde ${g.name} ${g.emoji} gönderdi!`);
  logChat(`🎁 ${from}: ${g.name} (${g.coin}C)`); speak(`${from}, ${g.coin} coin değerinde ${g.name} gönderdi.`); g.run();
}
GIFTS.forEach(g => { const b = document.createElement('button'); b.className = 'gift'; b.textContent = `${g.emoji} ${g.name.split(' ')[0]} (${g.coin}C)`; b.onclick = () => sendGift(g); $('gifts').appendChild(b); });

try { $('name').value = localStorage.getItem('halayName') || ''; } catch (e) {}
function join(name) {
  if (addDancer(name)) { logChat(`Sistem: ${name} halaya katıldı!`); setTicker(`${name} halaya girdi! 💃`); }
  else logChat(`Sistem: ${name} zaten halayda ya da halay dolu.`);
}
function handleMsg() {
  const m = $('msg').value.trim(); if (!m) return;
  const name = userName(); try { localStorage.setItem('halayName', $('name').value); } catch (e) {}
  logChat(`${name}: ${m}`);
  if (m.toLocaleLowerCase('tr') === 'anafor') join(name); else logChat('Sistem: katılmak için sadece "anafor" yaz!');
  $('msg').value = '';
}
$('send').onclick = handleMsg;
$('msg').addEventListener('keydown', e => { if (e.key === 'Enter') handleMsg(); });
$('btn-hide').onclick = () => $('ui').classList.toggle('off');
$('btn-music').onclick = e => { e.currentTarget.textContent = sfx.toggle() ? '🔊' : '🎵'; };
$('btn-bots').onclick = () => { for (let i = 0; i < 5; i++) join(pick(NAMES) + Math.floor(rnd(1, 99))); };
$('stage').addEventListener('click', () => $('ui').classList.remove('off')); // gizli arayüzü geri getir

/* ---------- Ana döngü ---------- */
const clock = new THREE.Clock(), tmp = new THREE.Vector3(), prev = new THREE.Vector3();
function animate() {
  requestAnimationFrame(animate);
  const dt = Math.min(clock.getDelta(), 0.05), t = clock.elapsedTime, now = performance.now();
  ringAngle += dt * 0.5;
  if (raidT >= 0) { raidT += dt; if (raidT > 7) raidT = -1; }
  const n = dancers.length, r = Math.min(Math.max(3.5, n * 0.55), 11), fleeing = raidT >= 0 && raidT < 4.5;
  dancers.forEach((d, i) => {
    const a = ringAngle + (i / n) * Math.PI * 2;
    tmp.set(Math.cos(a) * r + CENTER.x, 0, Math.sin(a) * r + CENTER.z);
    prev.copy(d.pos);
    d.pos.lerp(fleeing ? d.flee : tmp, Math.min(dt * (fleeing ? 1.8 : 2), 1));
    const dx = d.pos.x - prev.x, dz = d.pos.z - prev.z;
    d.pos.y = Math.abs(Math.sin(t * 8 + d.ph)) * 0.12; d.g.position.copy(d.pos);
    if (dx * dx + dz * dz > 1e-6) {
      let da = Math.atan2(dx, dz) - d.g.rotation.y; da = Math.atan2(Math.sin(da), Math.cos(da));
      d.g.rotation.y += da * Math.min(dt * 8, 1);
    }
    const s = Math.sin(t * 8 + d.ph);
    d.lL.rotation.x = s * 0.7; d.lR.rotation.x = -s * 0.7;
    d.aL.rotation.z = fleeing ? 0.3 : 1.1 + Math.sin(t * 8) * 0.12;
    d.aR.rotation.z = fleeing ? -0.3 : (d === leader ? -2.4 + Math.sin(t * 10) * 0.5 : -1.1 - Math.sin(t * 8) * 0.12);
    d.crown.rotation.y = t * 3;
  });
  bulbs.forEach((b, i) => b.scale.setScalar(0.8 + 0.3 * Math.sin(t * 4 + i)));
  for (let i = fx.length - 1; i >= 0; i--) if (!fx[i].update(dt)) fx.splice(i, 1);
  stepParticles(dt); drawLED(now);
  cam.position.set(camBase.x + Math.sin(t * 0.2) * 2, camBase.y, camBase.z); cam.lookAt(0, 2.5, -2);
  renderer.render(scene, cam);
}
animate();
