# 💍 Anafor & Hülya Düğünü — 01 Adana Hürriyet

Three.js ile 3D halay/düğün simülasyonu. GitHub Actions ile otomatik APK üretilir.

## Kullanım
- Sohbete **anafor** yaz → halaya katıl. 👥 butonu 5 test seyirci ekler.
- Hediyeler: 🌹 Gül (1C), 🏍️ Motor (20C), 🎆 Fişek (50C), 🚨 Baskın (100C)
- 🎵 davul-zurna müziği, 👁️ arayüzü gizle (ekrana dokununca geri gelir)

## APK
1. Dosyaları repoya yükle (`.github` klasörü dahil), `main` dalına push et.
2. Actions → **APK Derle** çalışır (elle: Run workflow).
3. APK: Actions → Artifacts, veya Releases → **En Güncel APK**.

## Yerelde test
`www/index.html` dosyasını tarayıcıda aç (Three.js yoksa CDN'den yüklenir).
