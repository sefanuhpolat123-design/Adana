# 💍 Anafor & Hülya Düğünü (01 Adana Hürriyet)

Three.js ile yapılmış 3D halay/düğün simülasyonu. Capacitor ile APK'ya çevrilir.

## GitHub'a yükleme
1. Yeni repo aç, bu klasörün içeriğini yükle (ZIP'i açıp dosyaları sürükle-bırak).
2. `main` dalına push edince **Actions** otomatik APK derler.
3. APK'yı iki yerden alabilirsin:
   - **Actions → son çalışma → Artifacts → adana-halay-dugunu-apk**
   - **Releases → "En Güncel APK" (latest)**

Elle çalıştırmak için: Actions → "APK Derle" → Run workflow.

## Yerelde test
Tarayıcıda `www/index.html` aç (Three.js yoksa CDN'den yüklenir).
