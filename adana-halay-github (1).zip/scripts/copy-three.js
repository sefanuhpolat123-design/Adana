// three.min.js dosyasını www/ içine kopyalar (APK çevrimdışı çalışsın diye)
const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, '..', 'node_modules', 'three', 'build', 'three.min.js');
const dst = path.join(__dirname, '..', 'www', 'three.min.js');
fs.copyFileSync(src, dst);
console.log('three.min.js kopyalandı ->', dst);
